import numpy as np

class Softmax():
    def __init__(self):
        """
        Multiclass Softmax (cross-entropy) classifier trained with SGD.
        """
        self.w = None
        self.alpha = 0.01        # learning rate (0.5 was too large)
        self.epochs = 200
        self.reg_const = 0.0005   # smaller regularization works better

        self.batch_size = 256

    def calc_gradient(self, X_batch, y_batch):
        """
        Gradient of softmax cross-entropy loss (+ L2 regularization).

        X_batch: (N, D+1)
        y_batch: (N,)
        """
        N = X_batch.shape[0]

        # Scores
        scores = X_batch @ self.w.T  # (N, C)

        # Numerical stability
        scores -= np.max(scores, axis=1, keepdims=True)

        exp_scores = np.exp(scores)
        probs = exp_scores / np.sum(exp_scores, axis=1, keepdims=True)

        # Gradient on scores
        dscores = probs
        dscores[np.arange(N), y_batch] -= 1
        dscores /= N

        grad_w = dscores.T @ X_batch

        # Regularization gradient
        grad_w += self.reg_const * self.w

        return grad_w

    def train(self, X_train, y_train):
        """
        Train softmax classifier with minibatch SGD.
        """

        # Flatten if images
        if len(X_train.shape) > 2:
            X_train = X_train.reshape(X_train.shape[0], -1)

        X_train = X_train.astype(np.float32)
        y_train = y_train.astype(int)

        N, D = X_train.shape
        C = int(np.max(y_train)) + 1

        # Add bias
        Xb = np.hstack([X_train, np.ones((N, 1), dtype=X_train.dtype)])

        # Initialize weights
        rng = np.random.default_rng(0)
        self.w = 0.001 * rng.standard_normal((C, D + 1)).astype(np.float32)

        # SGD
        for _ in range(self.epochs):

            idx = np.random.permutation(N)

            for start in range(0, N, self.batch_size):

                batch_idx = idx[start:start + self.batch_size]

                X_batch = Xb[batch_idx]
                y_batch = y_train[batch_idx]

                grad = self.calc_gradient(X_batch, y_batch)

                self.w -= self.alpha * grad

    def predict(self, X_test):
        """
        Predict labels.
        """

        if self.w is None:
            raise ValueError("Model not trained yet.")

        # Flatten if needed
        if len(X_test.shape) > 2:
            X_test = X_test.reshape(X_test.shape[0], -1)

        X_test = X_test.astype(np.float32)
        N = X_test.shape[0]

        # Add bias
        Xb = np.hstack([X_test, np.ones((N, 1), dtype=X_test.dtype)])

        scores = Xb @ self.w.T

        pred = np.argmax(scores, axis=1)

        return pred
