import numpy as np


class Perceptron():
    def __init__(self):
        """
        Initializes Perceptron classifier.
        """
        self.W = None  # (C, D+1) weights including bias
        self.alpha = 0.01
        self.epochs = 10
        self.num_classes = None

    def train(self, X_train, y_train):
        """
        Multiclass Perceptron (one weight vector per class).
        Update rule:
          y_hat = argmax_c (W_c · x)
          if y_hat != y:
              W_y     += alpha * x
              W_y_hat -= alpha * x
        """
        # Basic shapes
        N, D = X_train.shape
        y_train = y_train.astype(int)

        # Infer number of classes (CIFAR-10 => 10)
        self.num_classes = int(np.max(y_train)) + 1

        # Add bias feature
        Xb = np.hstack([X_train, np.ones((N, 1), dtype=X_train.dtype)])  # (N, D+1)

        # Initialize weights
        self.W = np.zeros((self.num_classes, D + 1), dtype=float)

        # Training loop
        for _ in range(self.epochs):
            # Optional: shuffle for better learning
            idx = np.random.permutation(N)
            for i in idx:
                x = Xb[i]  # (D+1,)
                y = y_train[i]  # int

                scores = self.W @ x  # (C,)
                y_hat = int(np.argmax(scores))

                if y_hat != y:
                    self.W[y] += self.alpha * x
                    self.W[y_hat] -= self.alpha * x

    def predict(self, X_test):
        """
        Predict class labels 0..C-1 for X_test.
        """
        if self.W is None:
            raise ValueError("Model not trained yet. Call train() first.")

        N = X_test.shape[0]
        Xb = np.hstack([X_test, np.ones((N, 1), dtype=X_test.dtype)])  # (N, D+1)

        scores = Xb @ self.W.T  # (N, C)
        pred = np.argmax(scores, axis=1).astype(int)
        return pred
