import numpy as np
import scipy


class KNN():
    def __init__(self, k):
        self.k = k

    def train(self, X, y):
        # Memorize training data
        self.X_train = X
        self.y_train = y

    def find_dist(self, X_test):
        """
        Returns a (num_test, num_train) distance matrix
        """
        # cdist(A, B) returns distances between each row of A and each row of B
        dist_ = scipy.spatial.distance.cdist(X_test, self.X_train, metric="euclidean")
        return dist_

    def predict(self, X_test):
        """
        Predict labels for X_test using k nearest neighbors.
        """
        dist_ = self.find_dist(X_test)  # shape (num_test, num_train)

        # Indices of k nearest neighbors for each test example
        knn_idx = np.argsort(dist_, axis=1)[:, :self.k]  # (num_test, k)

        # Neighbor labels
        knn_labels = self.y_train[knn_idx]  # (num_test, k)

        # Majority vote (works for labels 0..C-1)
        num_test = X_test.shape[0]
        pred = np.empty(num_test, dtype=self.y_train.dtype)

        for i in range(num_test):
            counts = np.bincount(knn_labels[i])
            pred[i] = np.argmax(counts)

        return pred
