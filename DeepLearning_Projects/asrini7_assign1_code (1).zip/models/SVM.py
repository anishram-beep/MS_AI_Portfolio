import numpy as np

class SVM():
    def __init__(self):
        """
        Linear multiclass SVM (hinge loss) trained with SGD.
        """
        self.w = None
        self.alpha = 0.01
        self.epochs = 100
        self.reg_const = 0.05

        # You can tweak this if runtime is high
        self.batch_size = 256

    def calc_gradient(self, X_batch, y_batch):
        """
        Compute gradient of multiclass SVM hinge loss on a minibatch.

        X_batch: (N, D)
        y_batch: (N,) labels in [0..C-1]
        returns: grad_w same shape as self.w (C, D+1) including bias row
        """
        N, Dp1 = X_batch.shape  # D+1 because we add bias
        C = self.w.shape[0]

        scores = X_batch @ self.w.T              # (N, C)
        correct_scores = scores[np.arange(N), y_batch].reshape(N, 1)  # (N,1)

        # margins = max(0, s_j - s_yi + 1)
        margins = scores - correct_scores + 1.0
        margins[np.arange(N), y_batch] = 0.0
        mask = (margins > 0).astype(float)       # (N, C)

        # For each i, count how many classes violated margin
        row_sum = np.sum(mask, axis=1)           # (N,)
        mask[np.arange(N), y_batch] = -row_sum   # put negative count in correct class column

        # Gradient (average over batch) + L2 regularization
        grad_w = (mask.T @ X_batch) / N          # (C, D+1)
        grad_w += self.reg_const * self.w        # d/dW (0.5*reg*||W||^2) style up to constant
        return grad_w

    def train(self, X_train, y_train):
        """
        Train SVM classifier using stochastic gradient descent over minibatches.
        """
        X_train = X_train.astype(np.float32)
        y_train = y_train.astype(int)

        N, D = X_train.shape
        C = int(np.max(y_train)) + 1  # CIFAR-10 -> 10

        # Add bias feature
        Xb = np.hstack([X_train, np.ones((N, 1), dtype=X_train.dtype)])  # (N, D+1)

        # Initialize weights small
        rng = np.random.default_rng(0)
        self.w = 0.001 * rng.standard_normal((C, D + 1)).astype(np.float32)

        for _ in range(self.epochs):
            idx = np.random.permutation(N)

            for start in range(0, N, self.batch_size):
                batch_idx = idx[start:start + self.batch_size]
                X_batch = Xb[batch_idx]
                y_batch = y_train[batch_idx]

                grad = self.calc_gradient(X_batch, y_batch)
                self.w -= self.alpha * grad

    def predict(self, X_test):
        """
        Predict labels using trained linear SVM weights.
        """
        if self.w is None:
            raise ValueError("Model not trained yet. Call train() first.")

        X_test = X_test.astype(np.float32)
        N = X_test.shape[0]

        # Add bias feature
        Xb = np.hstack([X_test, np.ones((N, 1), dtype=X_test.dtype)])  # (N, D+1)

        scores = Xb @ self.w.T          # (N, C)
        pred = np.argmax(scores, axis=1).astype(int)
        return pred
